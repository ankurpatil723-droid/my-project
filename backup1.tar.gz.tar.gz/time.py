import time
timestamp=(time.strftime('%H:%M:%S'))
print(timestamp)
hour=int(time.strftime('%H'))
print(timestamp)
timestamp=(time.strftime('%M'))
print(timestamp)
timestamp=(time.strftime('%S'))
print(timestamp)

#here write the folliwing the comdition to givfe me the 
#following the movement

if(hour>=0 and hour<=12):
   print("good morning baccho")
elif(hour>12 and hour<=18):
   print("good afternoon bachho")
elif(hour>18 and hour<=24):
   print("good night bachho")

name="ankur"
print(f"myself {name} patil from surwade bk")   