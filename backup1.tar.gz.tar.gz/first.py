print ("ankur patil is the royal person")
print (7*89)
# print ("enter the a:")
a=int(input("enter the a:"))
b=int (input("enter the b:"))

print ("product is:",a*b)