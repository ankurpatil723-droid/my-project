def great(a,b,c):
#     if(a>b and a>c):
#         print("a is greater ")

#     elif(b>a and b>c):
#         print("b is greater")

#     elif(c>a and c>b):
#         print("c is greater")        

#     else:
#         print("all number are the same")