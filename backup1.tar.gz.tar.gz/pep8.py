# def square(n):
#     '''hello my self ankur patil and i am lkeader of team cipherx'''
#     print(n**2)
# square(5)
# print(square.__doc__)    
def fac(o):
    if(o==1 or o==0):
        return 1;
    else:
        return o*fac(o-1)
print(fac(5))      