import shutil
import os


def create_backup(source_path,destination_path):

    backup_name=os.path.join(destination_path,"backup2")
    shutil.make_archive(backup_name,'gztar',source_path)
    print("Backup Completed")

source_path=r"/Users\Dell\Downloads\python"
destination_path=r"/Users\Dell\Downloads\python\backups" 


#here is the calling the following the function source path and the folloeing the destination path

create_backup(source_path,destination_path)